package entity;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class enemy extends entity {
    public static enemy[] listenemy = new enemy[99];
    public static int banyakenemy = 0;
    public BufferedImage enemysprite;
    public Main.gamePanel gp;
    private int patdistance = 5;
    private int movedistanceX = 0;
    private int movedistanceY = 0;
    private int rangepatrol;
    private int counter = 100;
    public String direction = "right";
    public int screenX, screenY, worldcol, worldrow;

    public Player player;
    public String Type;
    public String patType;
    private int precX, precY;
    public int sizeX, sizeY;


    public boolean isJumping = false;
    public int Jumptime = 0;
    public int jumptime = Jumptime;
    public int jumpforce = 0;
    public BufferedImage img1, img2, img3, img4, img5, img6, img7, img8;
    public boolean isAlive = true;
    public int speed;



    public enemy(Main.gamePanel gp, int rangepatrol, int speed, int posX, int posY, int sizeX, int sizeY, Player player, String type, String img1, String img2, String img3, String img4, String img5, String img6, String img7, String img8, int precX, int precY) {
        listenemy[banyakenemy] = this;
        banyakenemy += 1;
        this.speed = speed;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.Type = type;
        this.worldcol = posX;
        this.worldrow = posY;
        super.iscolliding = true;
        this.rangepatrol = rangepatrol;
        this.gp = gp;
        this.player = player;
        this.precX = precX;
        this.precY = precY;


        try {
            this.img1 = ImageIO.read(getClass().getResourceAsStream(img1));
            this.img2 = ImageIO.read(getClass().getResourceAsStream(img2));
            this.img3 = ImageIO.read(getClass().getResourceAsStream(img3));
            this.img4 = ImageIO.read(getClass().getResourceAsStream(img4));

            this.img5 = ImageIO.read(getClass().getResourceAsStream(img5));
            this.img6 = ImageIO.read(getClass().getResourceAsStream(img6));
            this.img7 = ImageIO.read(getClass().getResourceAsStream(img7));
            this.img8 = ImageIO.read(getClass().getResourceAsStream(img8));

        }catch (IOException e){
            e.printStackTrace();
        }

    }

    public void setPatType(String tipe){
            this.patType = tipe;
    }

    public void patrol() {
        if ( patType == "horizontal" ) {
            if (counter >= 0 && direction == "right") {
                screenX += patdistance;
                patdistance += speed;
            } else if (counter >= 0 && direction == "left") {
                screenX += patdistance;
                patdistance -= speed;
            }
            counter--;
            if (counter == 0 && direction == "right") {
                counter = rangepatrol;
                direction = "left";
            } else if (counter == 0 && direction == "left") {
                counter = rangepatrol;
                direction = "right";
            }
        } else if (patType == "vertikal"){
            if (counter >= 0 && direction == "right") {
                screenY += patdistance;
                patdistance += speed;
            } else if (counter >= 0 && direction == "left") {
                screenY += patdistance;
                patdistance -= speed;
            }
            counter--;
            if (counter == 0 && direction == "right") {
                counter = rangepatrol;
                direction = "left";
            } else if (counter == 0 && direction == "left") {
                counter = rangepatrol;
                direction = "right";
            }
        }
    }

    public void checkarea() {
        if (patType == "jalan"){
            if (player.screenY > (screenY + movedistanceY - gp.tileSize * 2) && (player.screenY < (screenY + movedistanceY + gp.tileSize * 2)) && (player.screenX > (screenX + movedistanceX - gp.tileSize * 10)) && (player.screenX < (screenX + movedistanceX + gp.tileSize * 10))) {
                if ((player.screenY - (screenY + movedistanceY) > -5) && (player.screenY - (screenY + movedistanceY) < 5) && (player.screenX - (screenX + movedistanceX) == 1 || player.screenX - (screenX + movedistanceX) == 0)) {
                    screenX += movedistanceX;
                } else {
                    if (player.health > 0) {
                        if (player.screenX > screenX + movedistanceX) {
                            screenX += movedistanceX;
                            movedistanceX += speed;
                        } else {
                            screenX += movedistanceX;
                            movedistanceX -= speed;
                        }
                    } else {
                        screenX += movedistanceX;
                    }
                }
            } else {
                screenX += movedistanceX;
            }

        }else if (patType == "terbang") {
            if (player.screenY > (screenY + movedistanceY - gp.tileSize * 10) && (player.screenY < (screenY + movedistanceY + gp.tileSize * 10)) && (player.screenX > (screenX + movedistanceX - gp.tileSize * 10)) && (player.screenX < (screenX + movedistanceX + gp.tileSize * 10))) {
                if ((player.screenY - (screenY + movedistanceY) > -5) && (player.screenY - (screenY + movedistanceY) < 5) && (player.screenX - (screenX + movedistanceX) == 1 || player.screenX - (screenX + movedistanceX) == 0)) {
                    screenY += movedistanceY;
                    screenX += movedistanceX;
                } else {
                    if (player.health > 0) {
                        if (player.screenY > (screenY+25) + movedistanceY) {
                            screenY += movedistanceY;
                            movedistanceY += speed;
                        } else {
                            screenY += movedistanceY;
                            movedistanceY -= speed;
                        }
                        if (player.screenX > screenX + movedistanceX) {
                            screenX += movedistanceX;
                            movedistanceX += speed;
                        } else {
                            screenX += movedistanceX;
                            movedistanceX -= speed;
                        }
                    } else {
                        screenY += movedistanceY;
                        screenX += movedistanceX;
                    }
                }
            } else {
                screenX += movedistanceX;
                screenY += movedistanceY;
            }
        }
    }

    public void jump(){
        if (jumptime==0){
            isJumping = true;
        }
        if (isJumping == true) {
            screenY -= jumpforce;
            jumpforce += 10;
            jumptime++;
            jumpforce -= jumptime;
        }else{

        }
    }

    public void setImage(){
        if(direction == "right"){
            if(player.spriteNum == 1){
                enemysprite = img1;
            } else if (player.spriteNum == 2) {
                enemysprite = img2;
            }else if(player.spriteNum == 3 ){
                enemysprite = img3;
            } else if (player.spriteNum == 4) {
                enemysprite = img4;
            }
        }else{
            if(player.spriteNum == 1){
                enemysprite = img5;
            } else if (player.spriteNum == 2) {
                enemysprite = img6;
            }else if(player.spriteNum == 3 ){
                enemysprite = img7;
            } else if (player.spriteNum == 4) {
                enemysprite = img8;
            }
        }

    }

    public void draw(Graphics2D g) {
        if(isAlive){
            int worldX = gp.tileSize * worldcol + precX;
            int worldY = gp.tileSize * worldrow + precY;
            screenX = worldX - (gp.player.worldX + gp.player.screenX);
            screenY = worldY - (gp.player.worldY + gp.player.screenY);
            if (Type =="ngincer"){
                checkarea();
            } else if (Type =="patrol") {
                patrol();
            }
            setImage();
            g.drawImage(enemysprite, screenX, screenY, gp.tileSize*sizeX, gp.tileSize*sizeY, null);
        }else{
            screenX = -9999;
            screenY = -9999;
            g.drawImage(enemysprite, screenX, screenY, 0, 0, null);
        }
    }
}
