package entity;

import java.awt.*;
import java.awt.image.BufferedImage;

public class entity{
    public int worldX, worldY;
    public int speed;

    public BufferedImage idleL1, idleL2, idleL3, idleL4, walkL1, walkL2, walkL3,walkL4, walk1, walk2, walk3, walk4, iddle1, iddle2, iddle3, iddle4, upimg, downimg;
    public String direction;

    public int spriteCounter = 0;
    public int spriteNum = 1;

    public Rectangle collider;
    public boolean iscolliding = false;
    public boolean iscollidingbottom = false;
    public boolean isGrounded = false;
    public boolean isMentokAtas = false;
    public boolean getDamaged = false;
    public boolean isknockbackL = false;
    public boolean isknockbackR = false;
    public boolean isHealing = false;

}
