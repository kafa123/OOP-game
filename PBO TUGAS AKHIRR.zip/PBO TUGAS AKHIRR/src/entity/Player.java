package entity;

import Main.gamePanel;
import inputs.keyboard;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;


// kalau mau nonaktifin health ada di bawah, didalam method update player, nanti di bagian knockback ada health --; itu di koman
//sekarang udah ko komen
public class Player extends entity{
    Main.gamePanel gp;
    inputs.keyboard keyboardInp;

    public boolean iswalking = false;

    public final int screenX;
    public final int screenY;
    public final int gravityForce = 4;
    public int gravityforce = gravityForce;

    public boolean isfloating;
    public int jumpForce = 25;
    public int jumpforce = jumpForce;
    public int knockforce = 19;
    public int knockForce = knockforce;
    public int jumplimit = 2;
    public int falltime = 0;
    public int fallCounter = 0;
    public int health = 3;
    public BufferedImage healthfull, healthempty;

    public boolean isDie = false;



    public Player(gamePanel panel, keyboard keyboardInp) {
        this.gp = panel;
        this.keyboardInp = keyboardInp;
        setDefaultValues();
        getPlayerImage();

        screenX = gp.screenWidth/2-gp.tileSize*2;
        screenY = (gp.screenHeight/2+gp.tileSize*2)+20;

        //bikin collidernya
        collider = new Rectangle();
        collider.x = 20;
        collider.y = 10;
        collider.width = collider.x+15;
        collider.height = gp.tileSize+5;

    }
    public void setDefaultValues(){
        worldX = gp.tileSize*100;
        worldY = gp.tileSize*100;
        speed = 6;
        direction = "right";
    }

    public void getPlayerImage(){
        try{
            healthfull = ImageIO.read(getClass().getResourceAsStream("ASET/health1.png"));
            healthempty = ImageIO.read(getClass().getResourceAsStream("ASET/health0.png"));
            upimg = ImageIO.read(getClass().getResourceAsStream("ASET/idle 1.png"));
            downimg = ImageIO.read(getClass().getResourceAsStream("ASET/idle 1.png"));

            idleL1 = ImageIO.read(getClass().getResourceAsStream("ASET/idlechar-0.png"));
            idleL2 = ImageIO.read(getClass().getResourceAsStream("ASET/idlechar-1.png"));
            idleL3 = ImageIO.read(getClass().getResourceAsStream("ASET/idlechar-2.png"));

            walk1 = ImageIO.read(getClass().getResourceAsStream("ASET/walkright-1.png"));
            walk2 = ImageIO.read(getClass().getResourceAsStream("ASET/walkright-4.png"));
            walk3 = ImageIO.read(getClass().getResourceAsStream("ASET/walkright-3.png"));
            walk4 = ImageIO.read(getClass().getResourceAsStream("ASET/walkright-1.png"));

            walkL1 = ImageIO.read(getClass().getResourceAsStream("ASET/walkleft-1.png"));
            walkL2 = ImageIO.read(getClass().getResourceAsStream("ASET/walkleft-4.png"));
            walkL3 = ImageIO.read(getClass().getResourceAsStream("ASET/walkleft-3.png"));
            walkL4 = ImageIO.read(getClass().getResourceAsStream("ASET/walkleft-1.png"));

            iddle1 = ImageIO.read(getClass().getResourceAsStream("ASET/idleright-0.png"));
            iddle2 = ImageIO.read(getClass().getResourceAsStream("ASET/idleright-1.png"));
            iddle3 = ImageIO.read(getClass().getResourceAsStream("ASET/idleright-2.png"));
            iddle4 = ImageIO.read(getClass().getResourceAsStream("ASET/idleright-1.png"));

        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void updatePlayer(){


        if(keyboardInp.upPressed == true){
            iswalking = true;
            direction = "up";
            worldY -= 15;
        }
        else if(keyboardInp.downPressed == true) {
            iswalking = true;
            direction = "down";
        }
        else if(keyboardInp.leftPressed == true) {
            iswalking = true;
            direction = "left";
        }
        else if(keyboardInp.rightPressed == true) {
            iswalking = true;
            direction = "right";
        }

        // Heal iteM
        if (isHealing == true){
            if(health>0 && health<3) {
                health++;
                isHealing = false;
            }
            isHealing = false;
        }


        // Collider Check
        iscolliding = false;
        iscollidingbottom = false;
        isGrounded = false;
        getDamaged = false;
        gp.colideCheck.checkCollision();


        if (getDamaged == true && health > 0){
            if(isknockbackL == false || isknockbackR == false){
                health--;
            }
            if(health == 0){
                isDie = true;
            }
        }
        if (isknockbackL == true){
            worldY -= knockforce;
            worldX -= knockforce;
            if(knockforce>0) {
                knockforce--;
            }else if(knockforce==0){
                isknockbackL = false;
                knockforce = knockForce;
            }
        } else if (isknockbackR == true) {
            worldY -= knockforce;
            worldX += knockforce;
            if(knockforce>0) {
                knockforce--;
            }else if(knockforce==0){
                isknockbackR = false;
                knockforce = knockForce;
            }
        }

        if(iscolliding == false && iswalking==true && isDie == false) {
            switch (direction) {
                case "right":
                    worldX += speed;
                    break;
                case "left":
                    worldX -= speed;
                    break;
            }
        }

        // buat lompatnyaa
        if(keyboardInp.isJumping == true) {
            isfloating =true;
        }

        if (isfloating == true){
            worldY -= jumpforce;
            if(jumpforce>0) {
                jumpforce--;
            }else{
                keyboardInp.isJumping = false;
            }
            if(isMentokAtas == true){
                jumpforce=0;
            }
        }

        // buat gravitasi
        if ( isGrounded == false && iscollidingbottom == false ){
            worldY += gravityforce;
            fallCounter++;
            if(fallCounter%5 == 0){
                gravityforce++;
            }
        }
        if(iscollidingbottom == true){
            isMentokAtas = false;
            jumplimit = 2;
            gravityforce = gravityForce;
            fallCounter = falltime;
            isfloating = false;
            isGrounded = true;
            jumpforce = jumpForce;
        }


        if (keyboardInp.upPressed == false && keyboardInp.rightPressed == false && keyboardInp.leftPressed == false && keyboardInp.downPressed == false  ){
            iswalking = false;
        }

        spriteCounter++;
        if(spriteCounter>6){
            if(spriteNum==1){
                spriteNum=2;
            }else if (spriteNum==2){
                spriteNum=3;
            }else if (spriteNum==3) {
                spriteNum=4;
            }else if (spriteNum==4){
                spriteNum=1;
            }
            spriteCounter = 0;
        }

//        System.out.println("X " + worldX);
//        System.out.println("Y " + worldY);

//        CheckpointChecker
        if( ( worldX>6700 && worldX<6900 && worldY>1500 && worldY<1800 )  ||  ( worldX>5500 && worldX < 5700 && worldY > 2300 && worldY < 2520) ){
            System.out.println("KENAAA");
            gp.checkPointX = worldX;
            gp.checkPointY = worldY;
        }
    }

    public void draw(Graphics2D g2){

        BufferedImage img = null;
        BufferedImage[] playerHealth = new BufferedImage[3];

        if(isDie == false) {
            if (iswalking) {
                switch (direction) {
                    case "up":
                        img = iddle1;
                        break;

                    case "right":
                        if (spriteNum == 1) {
                            img = walk1;
                        } else if (spriteNum == 2) {
                            img = walk2;
                        } else if (spriteNum == 3) {
                            img = walk3;
                        } else if (spriteNum == 4) {
                            img = walk4;
                        }
                        break;

                    case "down":
                        img = iddle1;
                        break;

                    case "left":
                        if (spriteNum == 1) {
                            img = walkL1;
                        } else if (spriteNum == 2) {
                            img = walkL2;
                        } else if (spriteNum == 3) {
                            img = walkL3;
                        } else if (spriteNum == 4) {
                            img = walkL4;
                        }
                        break;
                }
            } else {
                if (direction == "right" || direction == "up" || direction == "down") {
                    if (spriteNum == 1) {
                        img = iddle1;
                    } else if (spriteNum == 2) {
                        img = iddle2;
                    } else if (spriteNum == 3) {
                        img = iddle3;
                    } else if (spriteNum == 4) {
                        img = iddle2;
                    }
                } else if (direction == "left" || direction == "up" || direction == "down") {
                    if (spriteNum == 1) {
                        img = idleL1;
                    } else if (spriteNum == 2) {
                        img = idleL2;
                    } else if (spriteNum == 3) {
                        img = idleL3;
                    } else if (spriteNum == 4) {
                        img = idleL2;
                    }
                }
            }

            if (health == 3) {
                playerHealth[0] = healthfull;
                playerHealth[1] = healthfull;
                playerHealth[2] = healthfull;
            } else if (health == 2) {
                playerHealth[0] = healthfull;
                playerHealth[1] = healthfull;
                playerHealth[2] = healthempty;
            } else if (health == 1) {
                playerHealth[0] = healthfull;
                playerHealth[1] = healthempty;
                playerHealth[2] = healthempty;
            } else {
                playerHealth[0] = healthempty;
                playerHealth[1] = healthempty;
                playerHealth[2] = healthempty;
            }
        }else{
            img = upimg;
        }

        g2.drawImage(img, screenX, screenY, gp.tileSize*2, gp.tileSize*2, null);
        int healthposX = gp.tileSize;
        int healthposY = gp.tileSize;
        for (int i = 0; i<playerHealth.length; i++){
            g2.drawImage(playerHealth[i], healthposX, healthposY, gp.tileSize*2, gp.tileSize*2, null);
            healthposX += gp.tileSize+20;
        }


    }

}
