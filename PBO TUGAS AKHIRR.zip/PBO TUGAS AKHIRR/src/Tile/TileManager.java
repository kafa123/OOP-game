package Tile;

import Main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TileManager {
    Main.gamePanel tilepanel;
    public Tile[] tile;
    public int[][] matrikstile;

    public TileManager(gamePanel tilepanel){
        this.tilepanel = tilepanel;
        tile = new Tile[10];
        setTileImage();
        matrikstile = new int [tilepanel.maxworldX][tilepanel.maxworldY];
        loadMap("MAP.txt");
    }

    // Bikin Library asset Tiles
    public void setTileImage(){
        try{
            tile[0] = new Tile();
            tile[0].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/batudalem2.png"));
            tile[0].collision=true;

            tile[1] = new Tile();
            tile[1].tileSprite = ImageIO.read(getClass().getResourceAsStream("../entity/ASET/transparent.png"));

            tile[2] = new Tile();
            tile[2].tileSprite = ImageIO.read(getClass().getResourceAsStream("../entity/ASET/transparent.png"));
            tile[2].collision=true;

            tile[3] = new Tile();
            tile[3].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/batu3.png"));
            tile[3].collision = true;

            tile[4] = new Tile();
            tile[4].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/batu2.png"));
            tile[4].collision = true;

            tile[5] = new Tile();
            tile[5].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/TileAtas.png"));
            tile[5].collision = true;

            tile[6] = new Tile();
            tile[6].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/tileAtas2.png"));
            tile[6].collision = true;

            tile[7] = new Tile();
            tile[7].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/batuL.png"));
            tile[7].collision = true;

            tile[8] = new Tile();
            tile[8].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/batuR.png"));
            tile[8].collision = true;

            tile[9] = new Tile();
            tile[9].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/batuB.png"));
            tile[9].collision = true;

        }catch (IOException e){
            e.printStackTrace();
        }
    }

    // Load Map
    public void loadMap(String path){
        try {
            InputStream is = getClass().getResourceAsStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int kolom = 0;
            int baris = 0;

            while (kolom < tilepanel.maxworldX && baris < tilepanel.maxworldY) {
                String line = br.readLine();
                while (kolom < tilepanel.maxworldX) {
                    String listnumbers[] = line.split(" ");
                    int listnum = Integer.parseInt(listnumbers[kolom]);
                    matrikstile[kolom][baris] = listnum;
                    kolom++;
                }
                if (kolom == tilepanel.maxworldX) {
                    baris++;
                    kolom = 0;
                }
            }
            br.close();
        }
        catch (Exception ex) {
        }
    }


    // Untuk Render Mapnya
    public void draw(Graphics2D g){
        int worldcol = 0;
        int worldrow = 0;

        while (worldcol < tilepanel.maxworldX && worldrow < tilepanel.maxworldY){

            int tileNum = matrikstile[worldcol][worldrow];

            int worldX = tilepanel.tileSize * worldcol;
            int worldY = tilepanel.tileSize * worldrow;
            int screenX = worldX - tilepanel.player.worldX + tilepanel.player.screenX;
            int screenY = worldY - tilepanel.player.worldY + tilepanel.player.screenY;


            g.drawImage(tile[tileNum].tileSprite, screenX, screenY, tilepanel.tileSize, tilepanel.tileSize, null);
            worldcol++;

            if(worldcol == tilepanel.maxworldX){
                worldrow++;
                worldcol = 0;
            }
        }
    }


}
