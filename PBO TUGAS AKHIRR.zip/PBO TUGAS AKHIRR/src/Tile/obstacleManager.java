package Tile;

import Main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class obstacleManager {
    Main.gamePanel obstaclePanel;
    public Tile[] obstacleAsset;
    public int[][] matriksObstacle;

    public obstacleManager(gamePanel tilepanel){
        this.obstaclePanel = tilepanel;
        obstacleAsset = new Tile[10];
        setTileImage();
        matriksObstacle = new int [tilepanel.maxworldX][tilepanel.maxworldY];
        loadMap("OBSTACLE.txt");
    }

    // Bikin Library asset Tiles
    public void setTileImage(){
        try{

            obstacleAsset[0] = new Tile();
            obstacleAsset[0].tileSprite = ImageIO.read(getClass().getResourceAsStream("../entity/ASET/duri.png"));
            obstacleAsset[0].collision = true;
            obstacleAsset[0].canDamage = true;

            obstacleAsset[1] = new Tile();
            obstacleAsset[1].tileSprite = ImageIO.read(getClass().getResourceAsStream("../entity/ASET/transparent.png"));

            obstacleAsset[2] = new Tile();
            obstacleAsset[2].tileSprite = ImageIO.read(getClass().getResourceAsStream("../entity/ASET/health1.png"));
            obstacleAsset[2].canHeal = true;

            obstacleAsset[3] = new Tile();
            obstacleAsset[3].tileSprite = ImageIO.read(getClass().getResourceAsStream("ASET/platform.png"));
            obstacleAsset[3].collision = true;




        }catch (IOException e){
            e.printStackTrace();
        }
    }


    // Load Map
    public void loadMap(String path){
        try {
            InputStream is = getClass().getResourceAsStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int kolom = 0;
            int baris = 0;

            while (kolom < obstaclePanel.maxworldX && baris < obstaclePanel.maxworldY) {
                String line = br.readLine();
                while (kolom < obstaclePanel.maxworldX) {
                    String listnumbers[] = line.split(" ");
                    int listnum = Integer.parseInt(listnumbers[kolom]);
                    matriksObstacle[kolom][baris] = listnum;
                    kolom++;
                }
                if (kolom == obstaclePanel.maxworldX) {
                    baris++;
                    kolom = 0;
                }
            }
            br.close();
        }
        catch (Exception ex) {
        }
    }


    // Untuk Render Mapnya
    public void draw(Graphics2D g){
        int worldcol = 0;
        int worldrow = 0;

        while (worldcol < obstaclePanel.maxworldX && worldrow < obstaclePanel.maxworldY){

            int tileNum = matriksObstacle[worldcol][worldrow];

            int worldX = obstaclePanel.tileSize * worldcol;
            int worldY = obstaclePanel.tileSize * worldrow;
            int screenX = worldX - obstaclePanel.player.worldX + obstaclePanel.player.screenX;
            int screenY = worldY - obstaclePanel.player.worldY + obstaclePanel.player.screenY;

            g.drawImage(obstacleAsset[tileNum].tileSprite, screenX, screenY, obstaclePanel.tileSize, obstaclePanel.tileSize, null);
            worldcol++;

            if(worldcol == obstaclePanel.maxworldX){
                worldrow++;
                worldcol = 0;
            }
        }
    }


}

