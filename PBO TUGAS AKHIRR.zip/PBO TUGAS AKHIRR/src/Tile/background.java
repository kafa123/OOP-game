package Tile;

import Main.gamePanel;
import entity.Player;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class background {
    public BufferedImage bg;
    private int width;
    private int height;
    public Main.gamePanel gp;
    private int counter = 0;
    private int delay;
    public int tmpscreenX;
    public entity.Player player;
    public int movespeed;

    public int posX, posY;


    public background(gamePanel gp, String image, int delay, Player p, int movespeed,int posX, int posY, int width,int height) {
        this.posX = posX;
        this.posY = posY;
        this.movespeed = movespeed;
        this.tmpscreenX = (gp.tileSize * posX) - (gp.player.worldX + gp.player.screenX);
        this.gp = gp;
        this.delay = delay;
        this.player = p;
        this.height = height;
        this.width = width;
        try {
            bg = ImageIO.read(getClass().getResourceAsStream(image));
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updatepos(){
        if (player.iswalking == true && player.iscolliding == false && player.isknockbackR == false && player.isknockbackL == false){
            if(player.direction == "right"){
                counter++;
                if (counter%delay == 0){
                    tmpscreenX -= movespeed;
                }
            } else if (player.direction == "left") {
                counter--;
                if (counter%delay == 0){
                    tmpscreenX += movespeed;
                }
            }
        }
    }


    public void drawbg(Graphics2D g) {
        int worldY = gp.tileSize * posY-500;
        int screenY = worldY - (gp.player.worldY + gp.player.screenY);
        updatepos();
        g.drawImage(bg, tmpscreenX, screenY, width , height+200 , null);
    }
}
