package Tile;

import java.awt.image.BufferedImage;

public class Tile {
    BufferedImage tileSprite;
    public boolean collision = false;
    public boolean canDamage = false;
    public boolean canHeal = false;
}
