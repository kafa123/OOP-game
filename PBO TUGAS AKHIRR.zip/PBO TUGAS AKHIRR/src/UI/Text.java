package UI;

import Main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Text {
    public BufferedImage bg, tpbg;
    public Main.gamePanel gp;

    public int screenX, screenY, sizeX, sizeY;
    public entity.Player p;
    public String keterangan;
    public static Text[] listText = new Text[99];
    public static int banyakText = 0;
    public Text(String bg, String tpbg, gamePanel gp, int screenX, int screenY, entity.Player p, int sizeX, int sizeY, String keterangan) {
        listText[banyakText] = this;
        banyakText++;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.keterangan = keterangan;
        this.gp = gp;
        this.screenX = screenX;
        this.screenY = screenY;
        this.p = p;
        try {
            this.bg = ImageIO.read(getClass().getResourceAsStream(bg));
            this.tpbg = ImageIO.read(getClass().getResourceAsStream(tpbg));
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void draw(Graphics2D g){
        if(keterangan == "gameover") {
            if (p.health > 0) {
                g.drawImage(tpbg, screenX, screenY, sizeX, sizeY, null);
            } else {
                g.drawImage(bg, screenX, screenY, sizeX, sizeY, null);
            }
        } else if (keterangan == "menang") {
            if(gp.isWin == true){
                g.drawImage(bg, screenX, screenY, sizeX, sizeY, null);
            }else{
                g.drawImage(tpbg, screenX, screenY, sizeX, sizeY, null);
            }
        }
    }
}
