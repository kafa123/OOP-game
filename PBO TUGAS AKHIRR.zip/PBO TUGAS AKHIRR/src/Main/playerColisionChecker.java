package Main;


import entity.enemy;
import object.moveObbj;
import object.obj;

public class playerColisionChecker {
    gamePanel gp;
    entity.Player player;
    moveObbj plat;
    entity.enemy[] listenemy;
    public playerColisionChecker(gamePanel gp, entity.Player p, moveObbj plat, enemy[] listenemy ){
        this.gp = gp;
        this.player = p;
        this.plat = plat;
        this.listenemy = listenemy;
    }

    public void checkCollision() {
        //        cek collision duri
        for ( int i = 0; i< obj.jumlahObj; i++) {
            if (player.isDie == false) {
                if (obj.listObj[i].canCollide) {
                    if ((player.screenX+10 > obj.listObj[i].screenX && player.screenX+10 < obj.listObj[i].screenX + gp.tileSize * obj.listObj[i].sizeX) && (player.screenY+10 - (obj.listObj[i].screenY + 5) > -30 && player.screenY+10 - (obj.listObj[i].screenY + 5) < 50)) {
                        if (obj.listObj[i].keterangan == "duri") {
                            player.getDamaged = true;
                            if (player.screenX < obj.listObj[i].screenX + 50) {
                                player.isknockbackL = true;
                            } else {
                                player.isknockbackR = true;
                            }
                        } else if (obj.listObj[i].keterangan == "lava") {
                            player.health = 0;
                            if (player.screenX < obj.listObj[i].screenX + gp.tileSize * 2) {
                                player.isknockbackL = true;
                            } else {
                                player.isknockbackR = true;
                            }
                            player.isDie = true;
                        }
                    }
                }
            }
        }

//        cek collision enemy
        for ( int i = 0; i<enemy.banyakenemy; i++) {
            if (player.isDie == false) {
                if ((player.screenX + 10 > listenemy[i].screenX && player.screenX + 10 < listenemy[i].screenX + gp.tileSize) && (player.screenY - (listenemy[i].screenY + 5) > -20 && player.screenY - (listenemy[i].screenY + 5) < 50)) {
                    player.getDamaged = true;
                    if (player.screenX < listenemy[i].screenX) {
                        player.isknockbackL = true;
                    } else {
                        player.isknockbackR = true;
                    }
                } else if ((player.screenX + 10 > listenemy[i].screenX + 5 && player.screenX + 10 < listenemy[i].screenX + gp.tileSize - 5) && (player.screenY + gp.tileSize - (listenemy[i].screenY + 5) > -30 && player.screenY + gp.tileSize - (listenemy[i].screenY + 5) < 10)) {
                    int tmpscreenX = listenemy[i].screenX;
                    listenemy[i].isAlive = false;
                    if (player.screenX < tmpscreenX) {
                        player.isknockbackL = true;
                    } else {
                        player.isknockbackR = true;
                    }
                }
            }
        }

        // inisiasi si bates collidernya ( posisi sama ukuran )
        int playerLeftWorldX = player.worldX + player.collider.x;
        int playerRightWorldX = player.worldX + player.collider.x + player.collider.width;
        int playerTopWorldY = player.worldY + player.collider.y;
        int playerBottomWorldY = player.worldY + player.collider.y + player.collider.height;

        // inisiasi index buat nanti ngecek array tilesnya
        int playerLeftCol = playerLeftWorldX / gp.tileSize;
        int playerRightCol = playerRightWorldX / gp.tileSize;
        int playerTopRow = playerTopWorldY / gp.tileSize;
        int playerBottomRow = playerBottomWorldY / gp.tileSize;

        // variabel buat nyimpen si nilai array nya
        int tileNum1, tileNum2;


//      cek collider item platform
        int tmpcekY = (plat.screenY - player.screenY)-50;
        int tmpcekX = plat.screenX - player.screenX;
        if ((tmpcekY > -10 && tmpcekY < 10) && (tmpcekX > -50 && tmpcekX < 50)) {
            player.iscollidingbottom = true;
        }else{
            player.iscollidingbottom = false;
        }


        playerBottomRow = ( playerBottomWorldY + 9)/gp.tileSize;
        playerRightCol = ( playerRightWorldX - 25)/gp.tileSize;
        playerLeftCol = (playerLeftWorldX + 15)/gp.tileSize;
        tileNum1 = gp.layer1.matrikstile[playerRightCol][playerBottomRow];
        tileNum2 = gp.layer1.matrikstile[playerLeftCol][playerBottomRow];

        if(gp.layer1.tile[tileNum1].collision == true || gp.layer1.tile[tileNum2].collision == true ){
            player.iscollidingbottom = true;
        }
//        tileNum1 = gp.layer2.matriksObstacle[playerRightCol][playerBottomRow];
//        tileNum2 = gp.layer2.matriksObstacle[playerLeftCol][playerBottomRow];
//
//        if(gp.layer2.obstacleAsset[tileNum1].collision == true || gp.layer2.obstacleAsset[tileNum2].collision == true ){
//            player.iscollidingbottom = true;
//        }

        playerTopRow = ( playerTopWorldY + 8)/gp.tileSize;
        playerRightCol = ( playerRightWorldX - 20)/gp.tileSize;
        playerLeftCol = (playerLeftWorldX + 20)/gp.tileSize;
        tileNum1 = gp.layer1.matrikstile[playerRightCol][playerTopRow];
        tileNum2 = gp.layer1.matrikstile[playerLeftCol][playerTopRow];
        if(gp.layer1.tile[tileNum1].collision == true || gp.layer1.tile[tileNum2].collision == true ){
            player.isMentokAtas = true;
        }

        // pengecekan collision
        if (player.direction == "right"){
            playerTopRow = ( playerTopWorldY)/gp.tileSize;
            playerBottomRow = ( playerTopWorldY + 20)/gp.tileSize;
            playerRightCol = ( playerRightWorldX -5)/gp.tileSize;
            tileNum1 = gp.layer1.matrikstile[playerRightCol][playerTopRow];
            tileNum2 = gp.layer1.matrikstile[playerRightCol][playerBottomRow];
            if(gp.layer1.tile[tileNum1].collision == true || gp.layer1.tile[tileNum2].collision == true){
                player.iscolliding = true;
            }
        }
        else if (player.direction == "left") {
            playerTopRow = (playerTopWorldY) / gp.tileSize;
            playerBottomRow = (playerTopWorldY + 20) / gp.tileSize;
            playerLeftCol = (playerLeftWorldX + player.speed) / gp.tileSize;
            tileNum1 = gp.layer1.matrikstile[playerLeftCol][playerTopRow];
            tileNum2 = gp.layer1.matrikstile[playerLeftCol][playerBottomRow];
            if (gp.layer1.tile[tileNum1].collision == true || gp.layer1.tile[tileNum2].collision == true) {
                player.iscolliding = true;
            }
//            tileNum1 = gp.layer2.matriksObstacle[playerLeftCol][playerTopRow];
//            tileNum2 = gp.layer2.matriksObstacle[playerLeftCol][playerBottomRow];
//            if (gp.layer2.obstacleAsset[tileNum1].canDamage == true || gp.layer2.obstacleAsset[tileNum2].canDamage == true) {
//                player.getDamaged = true;
//            }
//            if(gp.layer2.obstacleAsset[tileNum1].canHeal == true || gp.layer2.obstacleAsset[tileNum2].canHeal == true ){
//                player.isHealing = true;
//                gp.layer2.matriksObstacle[playerLeftCol][playerTopRow] = 1;
//                gp.layer2.matriksObstacle[playerLeftCol][playerBottomRow] = 1;
//            }
        }
    }
}
