package Main;

import javax.swing.*;

public class Main {
    public static boolean gameStart = false;

    public static void main(String[] args) {
        JFrame window1 = new JFrame();
        window1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window1.setResizable(false);
        window1.setTitle("TUGAS AKHIR");
        window1.setVisible(true);

        gamePanel panel1 = new gamePanel();
        window1.add(panel1);
        window1.pack();
        window1.setLocationRelativeTo(null);
        panel1.startGameThread();
        panel1.requestFocus();
    }
}
