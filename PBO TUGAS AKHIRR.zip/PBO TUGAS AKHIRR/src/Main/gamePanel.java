package Main;

import Tile.background;
import UI.Text;
import entity.Player;
import entity.enemy;
import inputs.keyboard;
import object.ObjBackground5;
import object.moveObbj;
import object.obj;

import javax.swing.*;
import java.awt.*;


public class gamePanel extends JPanel implements Runnable{

    // ukuran layar
    final int oriTileSze = 16;
    final int scale = 2;
    public final int tileSize = scale*oriTileSze; // 16 x 2 = 32
    public final int maxColValue = 32;
    public final int maxRowValue = 24;
    public final int screenWidth = maxColValue * tileSize; // 768
    public final int screenHeight = maxRowValue * tileSize; // 576


    //Ukuran MAP
    public final int maxworldX = 260;
    public final int maxworldY = 125;
    public final int worldWidth = tileSize * maxworldX;
    public final int worldHeight = tileSize * maxworldY;

    int FPS = 80;
    Thread gameThread;

    keyboard keyboardInp = new keyboard();

    public entity.Player player = new Player(this, keyboardInp);
    public int checkPointX, checkPointY;
    public boolean isWin = false;



// BIKIN MAP SAMA BACKGROUND
    Tile.TileManager layer1 = new Tile.TileManager(this);
    Tile.obstacleManager layer2 = new Tile.obstacleManager(this);
    Tile.background bg = new Tile.background(this, "ASET/1 (1).png", 4, this.player, 1, 0, 25,worldWidth,worldHeight);
    Tile.background bg1 = new Tile.background(this, "ASET/2.png", 3, this.player, 2, 0, 25,worldWidth,worldHeight);
    Tile.background bg2 = new Tile.background(this, "ASET/3.png",  2, this.player, 3, 0, 25,worldWidth,worldHeight);
//    Tile.background bg3 = new Tile.background(this, "ASET/background4a.png",  1, this.player, 4, 0, 25,worldWidth+500,worldHeight+850);


// Bikin enemy di sini
    public entity.enemy enemy_ngincer1 = new enemy(this, 100, 4,  240, 106, 3,3, this.player, "ngincer", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png",0, 9);
    public entity.enemy enemy_ngincer2 = new enemy(this, 100, 4, 220, 106, 3,3,this.player, "ngincer", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png",0, 9);
    public entity.enemy enemy_ngincer3 = new enemy(this, 100, 4, 190, 95, 3,3, this.player, "ngincer", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png",0, 9);
    public entity.enemy enemy_ngincer4 = new enemy(this, 100, 4, 170, 90, 3,3,this.player, "ngincer", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png",0, 9);


    public entity.enemy enemy_patrol1 = new enemy(this,200, 4, 216, 132, 3,3,this.player, "patrol", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png", 0, -17);
    public entity.enemy enemy_patrol2 = new enemy(this, 200, 4, 264, 113, 3,3,this.player, "patrol", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png", 0, 0);
    public entity.enemy enemy_patrol3 = new enemy(this, 200,4, 264, 96, 3,3,this.player, "patrol", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png", 0, 0);
    public entity.enemy enemy_patrol4 = new enemy(this,200,4, 235, 92, 3,3,this.player, "patrol", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png", 0, 5);
    public entity.enemy enemy_patrol5 = new enemy(this,200, 4,  220, 92, 3,3,this.player, "patrol", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png", 0, 5);
    public entity.enemy enemy_patrol6 = new enemy(this,250, 4, 230, 81, 3,3,this.player, "patrol", "../entity/enemy/scp1_1.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_3.png", "../entity/enemy/scp1_2.png", "../entity/enemy/scp1_1L.png", "../entity/enemy/scp1_2L.png", "../entity/enemy/scp1_3L.png", "../entity/enemy/scp1_2L.png", 0, -17);

//   nah kalau mau ubah posisinya ganti aja posX sama posY nya
//   kalau ganti mode enemynya ganti typenya, nah kalau yang patrol, kalau mau ubah kanan kiri ada di method update di gamepanel
//    tiap bikin objek baru jangan lupa di draw di method draw yang ada di bawah
//    habis bikin enemy baru, tambahin enemynya ke parameter variabel playerCollisionChecker di gamepanel, biar bisa cek collision, trus ubah dikit class cek collisionya, nanti aku aja yg edit


//    UI game over
    public UI.Text teks1 = new UI.Text("../Tile/ASET/gameover.png", "../entity/ASET/transparent.png", this, 350, 200, player, 300, 300, "gameover");
    public UI.Text teks2 = new UI.Text("../Tile/ASET/retry.png", "../entity/ASET/transparent.png", this, 420, 430, player, 120, 120, "gameover");

    public UI.Text teks3 = new UI.Text("../Tile/ASET/menang.png", "../entity/ASET/transparent.png", this, 350, 200, player, 300, 300, "menang");
    Sound sound = new Sound();


//    BIKIN OBJECT INDIVIDU APAPUN
    public moveObbj moveObbj = new moveObbj(this,150, 30, 77, 3, 3,"../Tile/ASET/platform.png");
//    kalau mau bikin platform di sini, bikin aja object baru, ntar tinggal set posisi dan lain lainya
//    tiap bikin objek baru jangan lupa di draw di method draw yang ada di bawah


    public object.obj tutorteks1 = new obj(this, 127, 122, 12, 12, 0, 0, false, "../Tile/ASET/text1.png" );
    public object.obj tutorteks2 = new obj(this, 160, 122, 12, 12, 0, 0, false, "../Tile/ASET/text2.png" );
    public object.obj tutorteks3 = new obj(this, 182, 122, 12, 12, 0, 0, false, "../Tile/ASET/text3.png" );
    public object.obj tutorteks4 = new obj(this, 212, 122, 12, 12, 0, 0,false, "../Tile/ASET/text4.png" );


    public object.obj duri1 = new obj(this, 215, 107, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri2 = new obj(this, 214, 107, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );

    public object.obj duri9 = new obj(this, 234, 107, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri10 = new obj(this, 235, 107, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri14 = new obj(this, 228, 95, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri15 = new obj(this, 229, 95, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    //    duri kebalik
    public object.obj duri4 = new obj(this, 216, 83, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri5 = new obj(this, 217, 83, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri12 = new obj(this, 230, 83, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri13 = new obj(this, 231, 83, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );

    //    duri tutor
    public object.obj duri6 = new obj(this, 186, 132, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri7 = new obj(this, 187, 132, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );
    public object.obj duri8 = new obj(this, 188, 132, 1, 2, 0, 8, true, "duri", "../Tile/ASET/duri.png" );

    public object.obj lava1 = new obj(this, 47, 94, 39, 5, 0, 0,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava2 = new obj(this, 40, 132, 13, 5, 0, 0,true, "lava", "../Tile/ASET/lava.png" );


    public object.obj lava3 = new obj(this, 157, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava4 = new obj(this, 172, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava5 = new obj(this, 182, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava6 = new obj(this, 147, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava7 = new obj(this, 137, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava8 = new obj(this, 117, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );

    public object.obj lava9 = new obj(this, 233, 135, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava12 = new obj(this, 249, 135, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );

    public object.obj lava13 = new obj(this, 263, 135, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava14 = new obj(this, 233, 140, 42, 5, -2, 0,true, "lava", "../Tile/ASET/lava_bawah.png" );
    public object.obj lava10 = new obj(this, 172, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj lava11 = new obj(this, 182, 107, 16, 5, -2, 5,true, "lava", "../Tile/ASET/lava.png" );
    public object.obj rumah = new obj(this, 263, 57, 10, 10, -2, 5,false, "none", "../Tile/ASET/decorations/shop.png" );

    public ObjBackground5 Naga1= new ObjBackground5(this,90,70,84,8,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga2= new ObjBackground5(this,90,100,82,7,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga3= new ObjBackground5(this,90,120,84,6,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga4= new ObjBackground5(this,90,4,87,4,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga5= new ObjBackground5(this,90,140,110,6,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga7= new ObjBackground5(this,90,120,100,4,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga8= new ObjBackground5(this,90,4,90,4,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga9= new ObjBackground5(this,90,4,95,4,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga10= new ObjBackground5(this,90,4,85,7,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga11= new ObjBackground5(this,90,4,96,4,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga12= new ObjBackground5(this,90,4,87,6,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga13= new ObjBackground5(this,90,4,84,7,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");
    public ObjBackground5 Naga14= new ObjBackground5(this,90,4,86,5,3,3,"right","../Tile/ASET/dragon/dragon by captainskeleto1.png","../Tile/ASET/dragon/dragon by captainskeleto2.png","../Tile/ASET/dragon/dragon by captainskeleto3.png","../Tile/ASET/dragon/dragon by captainskeleto4.png","../Tile/ASET/dragon/dragon by captainskeleto5.png");

//    public object.obj lava6 = new obj(this, 152, 102, 43, 5, 0, 0,true, "lava", "../Tile/ASET/lava_bawah.png" );


//    BUAT BIKIN LAVA SAMA DURI
//    itu precX sama Y gunanya buat kalau kamu mau nggeser di posisi yang lebih detil

//    CEK collision player
    public playerColisionChecker colideCheck = new playerColisionChecker(this,player, moveObbj, enemy.listenemy);


//    MOUSE LISTENER
    inputs.mouseInp mouseinp = new inputs.mouseInp(player);


    public gamePanel(){
        this.checkPointX = player.worldX;
        this.checkPointY = player.worldY;
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.darkGray);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyboardInp);
        this.addMouseListener(mouseinp);
        enemy_patrol1.setPatType("horizontal");
        enemy_patrol2.setPatType("vertikal");
        enemy_patrol3.setPatType("vertikal");
        enemy_patrol4.setPatType("horizontal");
        enemy_patrol5.setPatType("horizontal");
        enemy_patrol6.setPatType("horizontal");
        enemy_ngincer1.setPatType("jalan");
        enemy_ngincer2.setPatType("jalan");
        enemy_ngincer3.setPatType("terbang");
        enemy_ngincer4.setPatType("terbang");
        playMusic(0);
    }


    public void startGameThread(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run(){
        while(gameThread!=null){
            double drawInterval = 1000000000/FPS;
            double nextDrawTime = System.nanoTime() + drawInterval;
            update();

            repaint();

            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime /= 1000000;

                if(remainingTime<0){
                    remainingTime = 0;
                }
                Thread.sleep((long) remainingTime);
                nextDrawTime += drawInterval;

            }
            catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void update(){
        player.updatePlayer();
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        Naga1.draw(g2);
        Naga3.draw(g2);
        Naga2.draw(g2);
        Naga4.draw(g2);
        Naga5.draw(g2);
        Naga7.draw(g2);
        Naga8.draw(g2);
        Naga9.draw(g2);
        Naga10.draw(g2);
        Naga11.draw(g2);
        Naga12.draw(g2);
        Naga13.draw(g2);
        Naga14.draw(g2);

        for (int i = 0; i<moveObbj.banyakMoveObj; i++){
            moveObbj.listmoveObj[i].draw(g2);
        }

        for (int i = 0; i < Tile.background.banyakBackground; i++){
            Tile.background.listBackground[i].drawbg(g2);
        }
//        bg.drawbg(g2);
//        bg1.drawbg(g2);
//        bg2.drawbg(g2);

        for (int i = 0; i<obj.jumlahObj; i++){
            obj.listObj[i].draw(g2);
        }

        layer1.draw(g2);
        teks1.draw(g2);

        for (int i = 0; i<enemy.banyakenemy; i++){
            enemy.listenemy[i].draw(g2);
        }

        player.draw(g2);
        moveObbj.draw(g2);

        for (int i = 0; i < Text.banyakText; i++){
            Text.listText[i].draw(g2);
        }

        if(player.isDie == true){
//            sound.stop();
            player.speed = 0;
            bg.movespeed = 0;
            bg1.movespeed = 0;
            bg2.movespeed = 0;
            player.jumpforce = 0;
            if(mouseinp.posX > 476-50 && mouseinp.posX < 476+50 && mouseinp.posY > 476-20 && mouseinp.posY < 476+20 ){
//                sound.play();
                player.isDie = false;
                player.health = 3;
                player.worldX = checkPointX;
                player.worldY = checkPointY;
                player.speed = 6;
                bg.movespeed = 1;
                bg1.movespeed = 2;
                bg2.movespeed = 3;
                mouseinp.posY = 0;
                mouseinp.posX = 0;
            }
        }
        if(isWin == true){
//            sound.stop();
            player.speed = 0;
            bg.movespeed = 0;
            bg1.movespeed = 0;
            bg2.movespeed = 0;
            player.jumpforce = 0;
        }
        g2.dispose();
    }

    public void playMusic(int i){
        sound.setFile(i);
        sound.play();
        sound.loop();

    }
//    public void stopMusic(){
//        sound.stop();
//    }
//    public void playSE(int i){
//        sound.setFile(i);
//        sound.play();
//    }
}