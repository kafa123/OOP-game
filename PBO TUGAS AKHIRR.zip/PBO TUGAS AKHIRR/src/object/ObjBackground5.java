package object;

import Main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class ObjBackground5 extends moveObbj{
    BufferedImage img1,img2,img3,img4,img5;
    int spriteNum=0,Speed;
    String Direction;

    public ObjBackground5(gamePanel gp, int range, int posX, int posY, int Speed,int sizeX, int sizeY, String Direction,String img1, String img2, String img3, String img4, String  img5) {
        super(gp, range, posX, posY, sizeX, sizeY,img1);
        this.Direction=Direction;
        this.Speed=Speed;
        iscolliding=false;
        try {
            this.img1 = ImageIO.read(getClass().getResourceAsStream(img1));
            this.img2 = ImageIO.read(getClass().getResourceAsStream(img2));
            this.img3 = ImageIO.read(getClass().getResourceAsStream(img3));
            this.img4 = ImageIO.read(getClass().getResourceAsStream(img4));
            this.img5 = ImageIO.read(getClass().getResourceAsStream(img5));

        }catch (IOException e){
            e.printStackTrace();
        }

    }
    public void Move() {
        if (Direction=="left"){
            screenX += distance;
            distance-=Speed;
            if (spriteNum%5==0){
                img=img1;
                spriteNum++;
            } else if (spriteNum%5==1) {
                img=img2;
                spriteNum++;
            }else if (spriteNum%5==2) {
                img=img3;
                spriteNum++;
            }else if (spriteNum%5==3) {
                img=img4;
                spriteNum++;
            }else if (spriteNum%5==4) {
                img=img5;
                spriteNum++;
            }

        } else if (Direction=="right") {
            screenX += distance;
            distance+=Speed;
            if (spriteNum%5==0){
                img=img1;
                spriteNum++;
            } else if (spriteNum%5==1) {
                img=img2;
                spriteNum++;
            }else if (spriteNum%5==2) {
                img=img3;
                spriteNum++;
            }else if (spriteNum%5==3) {
                img=img4;
                spriteNum++;
            }else if (spriteNum%5==4) {
                img=img5;
                spriteNum++;
            }
        }
    }
    public void draw(Graphics2D g) {
        int worldX = gp.tileSize * worldcol ;
        int worldY = gp.tileSize * worldrow ;
        screenX = worldX - (gp.player.worldX + gp.player.screenX);
        screenY = worldY - (gp.player.worldY + gp.player.screenY);
        Move();
        g.drawImage(img, screenX, screenY, gp.tileSize*sizeX, gp.tileSize*sizeY, null);
    }
}
