package object;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class obj {
    public BufferedImage img;
    public Main.gamePanel gp;
    public int screenX, screenY, worldcol, worldrow, sizeX, sizeY, precX, precY;
    public boolean canCollide;

    public static obj[] listObj = new obj[99];
    public static int jumlahObj = 0;
    public String  keterangan;

    public obj(Main.gamePanel gp, int posX, int posY, int sizeX, int sizeY, int precX, int precY, boolean canCollide, String image) {
        listObj[jumlahObj] = this;
        jumlahObj++;
        this.canCollide = canCollide;
        this.precX = precX;
        this.precY = precY;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.worldcol = posX;
        this.worldrow = posY;
        this.gp = gp;

        try{
            img = ImageIO.read(getClass().getResourceAsStream(image));
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public obj(Main.gamePanel gp, int posX, int posY, int sizeX, int sizeY, int precX, int precY, boolean canCollide, String keterangan, String image) {
        listObj[jumlahObj] = this;
        jumlahObj++;
        this.keterangan = keterangan;
        this.canCollide = canCollide;
        this.precX = precX;
        this.precY = precY;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.worldcol = posX;
        this.worldrow = posY;
        this.gp = gp;

        try{
            img = ImageIO.read(getClass().getResourceAsStream(image));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics2D g){
        int worldX = gp.tileSize * worldcol + precX;
        int worldY = gp.tileSize * worldrow + precY;
        screenX = worldX - (gp.player.worldX + gp.player.screenX);
        screenY = worldY - (gp.player.worldY + gp.player.screenY);
        g.drawImage(img, screenX, screenY, gp.tileSize*sizeX, gp.tileSize*sizeY, null);
    }
}
