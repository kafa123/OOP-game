package object;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class moveObbj {
    public BufferedImage img;
    public Main.gamePanel gp;
    public int distance = 5;
    public int rangemove;
    public int counter = 100;
    public String direction = "right";
    public int screenX;
    public int screenY;
    public int worldcol, worldrow, sizeX, sizeY;
    public boolean iscolliding;
    public static moveObbj[] listmoveObj = new moveObbj[99];
    public static int banyakMoveObj = 0;

    public moveObbj(Main.gamePanel gp, int range, int posX, int posY, int sizeX, int sizeY, String image) {
        listmoveObj[banyakMoveObj] = this;
        banyakMoveObj ++;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.worldcol = posX;
        this.worldrow = posY;
        this.iscolliding = true;
        this.rangemove = range;
        this.gp = gp;

        try{
            img = ImageIO.read(getClass().getResourceAsStream(image));
        }catch (IOException e){
            e.printStackTrace();
        }

    }

    public void Move() {
        if (counter >= 0 && direction == "right") {
            screenX += distance;
            distance+=2;
        } else if (counter >= 0 && direction == "left") {
            screenX += distance;
            distance-=2;
        }
        counter--;
        if (counter == 0 && direction == "right") {
            counter = rangemove;
            direction = "left";
        } else if (counter == 0 && direction == "left") {
            counter = rangemove;
            direction = "right";
        }
    }

    public void draw(Graphics2D g){
        int worldX = gp.tileSize * worldcol;
        int worldY = gp.tileSize * worldrow;
        screenX = worldX - (gp.player.worldX + gp.player.screenX);
        screenY = worldY - (gp.player.worldY + gp.player.screenY);
        Move();
        g.drawImage(img, screenX, screenY, gp.tileSize*sizeX, gp.tileSize*sizeY, null);
    }
}

