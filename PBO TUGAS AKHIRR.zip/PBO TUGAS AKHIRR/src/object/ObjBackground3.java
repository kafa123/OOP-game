package object;

import Main.gamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class ObjBackground3 extends moveObbj{
    BufferedImage img1,img2,img3;
    int spriteNum=0,Speed;
    String Direction;

    public ObjBackground3(gamePanel gp, int range, int posX, int posY,int Speed, int sizeX, int sizeY, String Direction,String img1, String img2, String img3) {
        super(gp, range, posX, posY, sizeX, sizeY,img1);
        this.Direction=direction;
        this.Speed=Speed;
        try {
            this.img1 = ImageIO.read(getClass().getResourceAsStream(img1));
            this.img2 = ImageIO.read(getClass().getResourceAsStream(img2));
            this.img3 = ImageIO.read(getClass().getResourceAsStream(img3));
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void Move() {
            if (Direction=="right"){
                screenX += distance;
                distance-=Speed;
                System.out.println(screenX);
                if (spriteNum%3==0){
                    img=img1;
                    spriteNum++;
                } else if (spriteNum%3==1) {
                    img=img2;
                    spriteNum++;
                }else if (spriteNum%3==2) {
                    img=img3;
                    spriteNum++;
                }
            } else if (Direction=="right") {
                screenX += distance;
                distance+=Speed;
                System.out.println(screenX);
                if (spriteNum%3==0){
                    img=img1;
                    spriteNum++;
                } else if (spriteNum%3==1) {
                    img=img2;
                    spriteNum++;
                }else if (spriteNum%3==2) {
                    img=img3;
                    spriteNum++;
                }
            }
    }
    public void draw(Graphics2D g) {
        int worldX = gp.tileSize * worldcol ;
        int worldY = gp.tileSize * worldrow ;
        screenX = worldX - (gp.player.worldX + gp.player.screenX);
        screenY = worldY - (gp.player.worldY + gp.player.screenY);
        Move();
        g.drawImage(img, screenX, screenY, gp.tileSize*sizeX, gp.tileSize*sizeY, null);
    }
    }
