package inputs;

import entity.Player;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
public class mouseInp implements MouseListener, MouseMotionListener{
    public entity.Player p;
    public int posX = 0, posY = 0;

    public mouseInp(Player p) {
        this.p = p;
    }
    public mouseInp() {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse clicked");
    }

    @Override
    public void mousePressed(MouseEvent e) {
        posX = e.getX();
        posY = e.getY();
        System.out.println("posisi X = " + posX + " posisi Y = " + posY);
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        System.out.println("mouse dragged");
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
