package inputs;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class keyboard implements KeyListener {
    public boolean upPressed, rightPressed, downPressed, leftPressed;
    public boolean isJumping = false;
    public boolean canJump = false;

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int kode = e.getKeyCode();

        if (kode == KeyEvent.VK_W) {
            upPressed = true;
        } else if (kode == KeyEvent.VK_D) {
            rightPressed = true;
        } else if (kode == KeyEvent.VK_S) {
            downPressed = true;
        } else if (kode == KeyEvent.VK_A) {
            leftPressed = true;
        }
        if( kode == KeyEvent.VK_SPACE){
            isJumping = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int kode = e.getKeyCode();
        if (kode == KeyEvent.VK_W) {
            upPressed = false;
        } else if (kode == KeyEvent.VK_D) {
            rightPressed = false;
        } else if (kode == KeyEvent.VK_S) {
            downPressed = false;
        } else if (kode == KeyEvent.VK_A) {
            leftPressed = false;
        }
    }
}
